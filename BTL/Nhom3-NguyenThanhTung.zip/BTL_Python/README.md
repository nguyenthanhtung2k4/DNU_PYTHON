# BTL_Python
Bài tập lớn Python
Xây dựng các Chức Năng giúp quản lý khách sản
Menu gồm 20 Chức năng:
          #0.Thoát Chương Trình
          #1.Thêm phòng mới: Thêm thông tin một phòng mới vào hệ thống.
          #2.Sửa thông tin phòng: Cập nhật thông tin của một phòng đã tồn tại.
          #3.Xóa phòng: Xóa thông tin một phòng khỏi hệ thống.
          #4.Xem danh sách phòng: Hiển thị danh sách tất cả các phòng và tình trạng của chúng.
          #5.Hiện  thị  các phòng trống; 
          #6.Sửa thông tin khách hàng: Cập nhật thông tin của một khách hàng đã tồn tại.
          #7.Xem danh sách khách hàng: Hiển thị danh sách tất cả các khách hàng.
          #8.Đặt phòng mới: Tạo một đơn đặt phòng mới.
          #9.Hủy đặt phòng : Hủy một đơn đặt phòng đã tồn tại.
          #10.Nhận phòng : Xác nhận khách đã nhận phòng.
          #11.Trả phòng: Xác nhận khách đã trả phòng, tính toán số tiền cần thanh toán.
          #12.Xem danh sách đặt phòng: Hiển thị danh sách tất cả các đơn đặt phòng.
          #13.Thêm nhân viên mới: Thêm thông tin một nhân viên mới vào hệ thống.
          #14.Sửa thông tin nhân viên: Cập nhật thông tin của một nhân viên đã tồn tại.
          #15.Xóa nhân viên: Xóa thông tin một nhân viên khỏi hệ thống.
          #16.Xem danh sách nhân viên: Hiển thị danh sách tất cả các nhân viên.
          #17.Xem báo cáo doanh thuHiển thị báo cáo doanh thu chi tiết.
          #18.Setting
          #19.About
Các chức năng được xây dựng bởi sinh viên DNU: Nguyên Thanh Tùng | Lê Văn Vượng | Bùi Quang Tuấn
